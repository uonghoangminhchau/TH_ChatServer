﻿namespace BT1_Buoi2_Server
{
    partial class ChatServer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSend = new System.Windows.Forms.Button();
            this.btnImage = new System.Windows.Forms.Button();
            this.lblClientIp = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.btnFile = new System.Windows.Forms.Button();
            this.btnMusic = new System.Windows.Forms.Button();
            this.txtClientIp = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(491, 260);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(127, 100);
            this.btnSend.TabIndex = 0;
            this.btnSend.Text = "Send";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnImage
            // 
            this.btnImage.Location = new System.Drawing.Point(503, 166);
            this.btnImage.Name = "btnImage";
            this.btnImage.Size = new System.Drawing.Size(101, 48);
            this.btnImage.TabIndex = 1;
            this.btnImage.Text = "Images";
            this.btnImage.UseVisualStyleBackColor = true;
            // 
            // lblClientIp
            // 
            this.lblClientIp.AutoSize = true;
            this.lblClientIp.Location = new System.Drawing.Point(26, 9);
            this.lblClientIp.Name = "lblClientIp";
            this.lblClientIp.Size = new System.Drawing.Size(46, 13);
            this.lblClientIp.TabIndex = 2;
            this.lblClientIp.Text = "Client IP";
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.Location = new System.Drawing.Point(26, 244);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(50, 13);
            this.lblMessage.TabIndex = 3;
            this.lblMessage.Text = "Message";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(29, 42);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(442, 199);
            this.listBox1.TabIndex = 4;
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(29, 260);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(442, 100);
            this.txtMessage.TabIndex = 5;
            // 
            // btnFile
            // 
            this.btnFile.Location = new System.Drawing.Point(503, 58);
            this.btnFile.Name = "btnFile";
            this.btnFile.Size = new System.Drawing.Size(101, 48);
            this.btnFile.TabIndex = 1;
            this.btnFile.Text = "Files";
            this.btnFile.UseVisualStyleBackColor = true;
            // 
            // btnMusic
            // 
            this.btnMusic.Location = new System.Drawing.Point(503, 112);
            this.btnMusic.Name = "btnMusic";
            this.btnMusic.Size = new System.Drawing.Size(101, 48);
            this.btnMusic.TabIndex = 1;
            this.btnMusic.Text = "Musics";
            this.btnMusic.UseVisualStyleBackColor = true;
            // 
            // txtClientIp
            // 
            this.txtClientIp.Location = new System.Drawing.Point(78, 5);
            this.txtClientIp.Name = "txtClientIp";
            this.txtClientIp.Size = new System.Drawing.Size(177, 20);
            this.txtClientIp.TabIndex = 6;
            // 
            // ChatServer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(630, 372);
            this.Controls.Add(this.txtClientIp);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.lblClientIp);
            this.Controls.Add(this.btnMusic);
            this.Controls.Add(this.btnFile);
            this.Controls.Add(this.btnImage);
            this.Controls.Add(this.btnSend);
            this.Name = "ChatServer";
            this.Text = "Chat Server";
            this.Load += new System.EventHandler(this.ChatServer_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnImage;
        private System.Windows.Forms.Label lblClientIp;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Button btnFile;
        private System.Windows.Forms.Button btnMusic;
        private System.Windows.Forms.TextBox txtClientIp;
    }
}

